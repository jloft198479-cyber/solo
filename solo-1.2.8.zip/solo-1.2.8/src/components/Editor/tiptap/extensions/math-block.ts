/**
 * 数学公式块扩展
 *
 * 支持 $$ ... $$ 块级数学公式。
 * 渲染态：KaTeX 渲染的数学公式
 * 点击：进入 LaTeX 源码编辑模式
 */
import { Node, mergeAttributes } from '@tiptap/vue-3';
import type { Node as PMNode } from '@tiptap/pm/model';

// 异步加载 KaTeX（懒加载，减少首屏 bundle 体积）
let katexPromise: Promise<typeof import('katex')> | null = null;
export function getKatex() {
  if (!katexPromise) {
    katexPromise = (async () => {
      const katex = await import('katex');
      // 首次使用 KaTeX 时注入其 CSS，文档无公式时不加载
      await import('katex/dist/katex.min.css');
      return katex;
    })();
  }
  return katexPromise;
}

export const MathBlock = Node.create({
  name: 'mathBlock',
  group: 'block',
  content: 'text*',
  marks: '',
  code: true,
  defining: true,
  isolating: true,

  addAttributes() {
    return {};
  },

  parseHTML() {
    return [{ tag: 'div[data-type="math-block"]' }];
  },

  renderHTML({ HTMLAttributes }) {
    return [
      'div',
      mergeAttributes(HTMLAttributes, { 'data-type': 'math-block', class: 'mk-math-block' }),
      0,
    ];
  },

  addNodeView() {
    return ({ node, getPos, editor }) => {
      // 外层容器
      const dom = document.createElement('div');
      dom.className = 'mk-math-block';

      // 渲染区域
      const renderDiv = document.createElement('div');
      renderDiv.className = 'mk-math-render';
      dom.appendChild(renderDiv);

      // 编辑区域（textarea）
      const editDiv = document.createElement('div');
      editDiv.className = 'mk-math-edit';
      editDiv.style.display = 'none';

      const textarea = document.createElement('textarea');
      textarea.className = 'mk-math-textarea';
      textarea.placeholder = '输入 LaTeX 公式...';
      editDiv.appendChild(textarea);
      dom.appendChild(editDiv);

      let isEditing = false;
      let renderVersion = 0;
      let destroyed = false;
      // 统一管理事件监听器，destroy 时一次性清理
      const eventController = new AbortController();

      async function renderKatex(latex: string) {
        const version = ++renderVersion;
        renderDiv.replaceChildren();
        if (!latex.trim()) {
          const placeholder = document.createElement('span');
          placeholder.className = 'mk-math-placeholder';
          placeholder.textContent = '点击输入数学公式';
          renderDiv.appendChild(placeholder);
          return;
        }
        try {
          const katex = await getKatex();
          if (destroyed || version !== renderVersion) return;
          renderDiv.innerHTML = katex.default.renderToString(latex, {
            displayMode: true,
            throwOnError: false,
            trust: false,
          });
        } catch {
          if (destroyed || version !== renderVersion) return;
          const error = document.createElement('span');
          error.className = 'mk-math-error';
          error.textContent = latex;
          renderDiv.appendChild(error);
        }
      }

      function enterEdit() {
        if (isEditing) return;
        isEditing = true;
        const latex = node.textContent;
        textarea.value = latex;
        renderDiv.style.display = 'none';
        editDiv.style.display = 'block';
        textarea.focus();
        textarea.selectionStart = textarea.selectionEnd = textarea.value.length;
      }

      function exitEdit() {
        if (!isEditing) return;
        isEditing = false;
        const newLatex = textarea.value;
        editDiv.style.display = 'none';
        renderDiv.style.display = 'block';

        // 更新节点内容
        if (typeof getPos === 'function') {
          const pos = getPos();
          if (pos != null) {
            const tr = editor.view.state.tr;
            const nodeSize = node.nodeSize;
            const from = pos + 1; // 跳过节点开始
            const to = pos + nodeSize - 1; // 节点结束前

            if (newLatex) {
              tr.replaceWith(from, to, editor.view.state.schema.text(newLatex));
            } else {
              tr.delete(from, to);
            }
            editor.view.dispatch(tr);
          }
        }

        renderKatex(newLatex);
      }

      // 点击渲染区进入编辑
      renderDiv.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        enterEdit();
      }, { signal: eventController.signal });

      // 失焦退出编辑
      textarea.addEventListener('blur', () => {
        exitEdit();
      }, { signal: eventController.signal });

      // Escape 退出编辑
      textarea.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
          e.preventDefault();
          exitEdit();
          editor.commands.focus();
        }
      }, { signal: eventController.signal });

      // 初始渲染
      renderKatex(node.textContent);

      return {
        dom,
        // 不让 ProseMirror 管理内容区域
        contentDOM: undefined,
        update(updatedNode: PMNode) {
          if (updatedNode.type.name !== 'mathBlock') return false;
          node = updatedNode;
          if (!isEditing) {
            renderKatex(node.textContent);
          }
          return true;
        },
        stopEvent(event: Event) {
          // 在编辑模式下，拦截所有事件
          if (isEditing) return true;
          return event.type === 'mousedown' || event.type === 'click';
        },
        ignoreMutation() {
          return true;
        },
        destroy() {
          destroyed = true;
          renderVersion += 1;
          // 清理所有事件监听器，防止内存泄漏
          eventController.abort();
        },
      };
    };
  },
});
