/**
 * Markdown → ProseMirror Document 解析器
 *
 * 使用 markdown-it 解析 markdown 文本，转换为 ProseMirror 文档节点。
 * 基于 prosemirror-markdown 的 MarkdownParser 模式，但自定义 token 映射以支持 GFM 扩展。
 */
import MarkdownIt from 'markdown-it';
import type Token from 'markdown-it/lib/token.mjs';
import { Mark } from '@tiptap/pm/model';
import type { Schema, Node as PMNode, MarkType, NodeType } from '@tiptap/pm/model';

// markdown-it 插件
import markdownItTaskLists from 'markdown-it-task-lists';
import markdownItMark from 'markdown-it-mark';
import markdownItSub from 'markdown-it-sub';
import markdownItSup from 'markdown-it-sup';
import markdownItTexmath from 'markdown-it-texmath';
import markdownItFootnote from 'markdown-it-footnote';
import {
  getPluginFenceHandlers,
  getPluginPreprocessors,
  getPluginTokenHandlers,
  getPluginTokenInterceptors,
} from './plugins';

// ── markdown-it 实例 ───────────────────────────────────────────

// texmath 插件需要一个 KaTeX 引擎用于渲染 HTML，但解析器只调用 md.parse()（仅分词），
// 不调用 md.render()，因此引擎永远不会被调用。传入空壳对象避免静态导入 KaTeX，
// 使 KaTeX 可以作为独立 chunk 懒加载（由 math-block/math-inline 的 NodeView 按需加载）。
const dummyKatexEngine = {
  renderToString: (latex: string) => latex,
};

function createMarkdownIt(): MarkdownIt {
  const md = new MarkdownIt('commonmark', { html: false, linkify: false })
    .enable(['table', 'strikethrough']);

  md.use(markdownItTaskLists, { enabled: true, label: false });
  md.use(markdownItMark);
  md.use(markdownItSub);
  md.use(markdownItSup);
  md.use(markdownItTexmath, {
    engine: dummyKatexEngine,
    delimiters: 'dollars',
  });

  md.use(markdownItFootnote);

  return md;
}

// ── Token → PM 节点映射 ────────────────────────────────────────

interface StackItem {
  type: NodeType;
  attrs: Record<string, unknown>;
  content: PMNode[];
  marks: readonly Mark[];
}

export class MarkdownParseState {
  schema: Schema;
  stack: StackItem[];
  marks: readonly Mark[];
  pluginData: Record<string, unknown>;

  constructor(schema: Schema, pluginData: Record<string, unknown> = {}) {
    this.schema = schema;
    this.stack = [{ type: schema.nodes.doc, attrs: {}, content: [], marks: Mark.none }];
    this.marks = Mark.none;
    this.pluginData = pluginData;
  }

  get top(): StackItem {
    return this.stack[this.stack.length - 1];
  }

  addText(text: string) {
    if (!text) return;
    const top = this.top;
    const nodes = top.content;
    const last = nodes[nodes.length - 1];
    const textNode = this.schema.text(text, this.marks);
    if (last?.isText && Mark.sameSet(last.marks, textNode.marks)) {
      nodes[nodes.length - 1] = this.schema.text(last.text! + text, this.marks);
    } else {
      nodes.push(textNode);
    }
  }

  openMark(markType: MarkType, attrs?: Record<string, unknown>) {
    this.marks = markType.create(attrs).addToSet(this.marks);
  }

  closeMark(markType: MarkType) {
    this.marks = markType.removeFromSet(this.marks);
  }

  openNode(type: NodeType, attrs: Record<string, unknown> = {}) {
    this.stack.push({ type, attrs, content: [], marks: Mark.none });
  }

  closeNode(): PMNode {
    const item = this.stack.pop()!;
    const node = item.type.createAndFill(item.attrs, item.content, this.marks);
    if (!node) {
      // 兜底：创建空段落
      return this.schema.nodes.paragraph.create();
    }
    this.top.content.push(node);
    return node;
  }

  addNode(type: NodeType, attrs: Record<string, unknown> = {}, content?: PMNode[]) {
    const node = type.createAndFill(attrs, content);
    if (node) this.top.content.push(node);
    return node;
  }

  buildDoc(): PMNode {
    while (this.stack.length > 1) this.closeNode();
    return this.top.type.createAndFill(this.top.attrs, this.top.content) || this.schema.nodes.doc.create();
  }
}

// ── Token 处理器 ────────────────────��───────────────────────────

export type TokenHandler = (
  state: MarkdownParseState,
  token: Token,
  tokens: Token[],
  index: number,
) => void;

export function getTokenHandlers(schema: Schema): Record<string, TokenHandler> {
  const handlers: Record<string, TokenHandler> = {};
  const fenceHandlers = getPluginFenceHandlers(schema);

  // ── 块级节点 ──

  handlers.paragraph_open = (state) => {
    state.openNode(schema.nodes.paragraph);
  };
  handlers.paragraph_close = (state) => {
    state.closeNode();
  };

  handlers.heading_open = (state, token) => {
    const level = parseInt(token.tag.slice(1));
    state.openNode(schema.nodes.heading, { level });
  };
  handlers.heading_close = (state) => {
    state.closeNode();
  };

  handlers.blockquote_open = (state) => {
    state.openNode(schema.nodes.blockquote);
  };
  handlers.blockquote_close = (state) => {
    state.closeNode();
  };

  handlers.bullet_list_open = (state, _token, tokens, index) => {
    // 前看：检查列表项是否包含任务列表标记（class="task-list-item"）
    if (schema.nodes.taskList && schema.nodes.taskItem) {
      for (let i = index + 1; i < tokens.length; i++) {
        const t = tokens[i];
        if (t.type === 'bullet_list_close') break;
        if (t.type === 'list_item_open') {
          const cls = t.attrGet('class');
          if (cls?.includes('task-list-item')) {
            state.openNode(schema.nodes.taskList);
            return;
          }
        }
      }
    }
    state.openNode(schema.nodes.bulletList);
  };
  handlers.bullet_list_close = (state) => {
    state.closeNode();
  };

  handlers.ordered_list_open = (state, token) => {
    const start = token.attrGet('start');
    state.openNode(schema.nodes.orderedList, { start: start ? parseInt(start) : 1 });
  };
  handlers.ordered_list_close = (state) => {
    state.closeNode();
  };

  handlers.list_item_open = (state, token) => {
    // 检测是否是任务列表项
    // markdown-it-task-lists 在 li_open 的 class 中标记 task-list-item
    // checked 状态实际在子 html_inline 的 <input checked="" ...> 中，不在 class 里
    const isTask = token.attrGet('class')?.includes('task-list-item') ?? false;
    if (isTask) {
      state.openNode(schema.nodes.taskItem, { checked: false });
    } else {
      state.openNode(schema.nodes.listItem);
    }
  };
  handlers.list_item_close = (state) => {
    state.closeNode();
  };

  handlers.code_block = (state, token) => {
    state.addNode(schema.nodes.codeBlock, { language: null }, [
      schema.text(token.content.replace(/\n$/, '') || ' '),
    ]);
  };

  handlers.fence = (state, token) => {
    const lang = token.info?.trim()?.toLowerCase() || null;
    const content = token.content.replace(/\n$/, '');

    for (const handler of fenceHandlers) {
      if (handler(state, token, lang, content)) {
        return;
      }
    }

    state.addNode(schema.nodes.codeBlock, { language: lang }, content ? [schema.text(content)] : undefined);
  };

  handlers.hr = (state) => {
    state.addNode(schema.nodes.horizontalRule);
  };

  // ── 表格 ──

  handlers.table_open = (state) => {
    state.openNode(schema.nodes.table);
  };
  handlers.table_close = (state) => {
    state.closeNode();
  };

  handlers.thead_open = () => { /* skip, rows handled directly */ };
  handlers.thead_close = () => {};
  handlers.tbody_open = () => {};
  handlers.tbody_close = () => {};

  handlers.tr_open = (state) => {
    state.openNode(schema.nodes.tableRow);
  };
  handlers.tr_close = (state) => {
    state.closeNode();
  };

  handlers.th_open = (state) => {
    state.openNode(schema.nodes.tableHeader);
    state.openNode(schema.nodes.paragraph);
  };
  handlers.th_close = (state) => {
    state.closeNode(); // paragraph
    state.closeNode(); // tableHeader
  };

  handlers.td_open = (state) => {
    state.openNode(schema.nodes.tableCell);
    state.openNode(schema.nodes.paragraph);
  };
  handlers.td_close = (state) => {
    state.closeNode(); // paragraph
    state.closeNode(); // tableCell
  };

  // ── 图片 ──

  handlers.image = (state, token) => {
    const src = token.attrGet('src') || '';
    const alt = token.content || token.children?.map(t => t.content).join('') || '';
    const title = token.attrGet('title') || null;
    state.addNode(schema.nodes.image, { src, alt, title });
  };

  // ── 行内标记 ──

  handlers.em_open = (state) => {
    state.openMark(schema.marks.italic);
  };
  handlers.em_close = (state) => {
    state.closeMark(schema.marks.italic);
  };

  handlers.strong_open = (state) => {
    state.openMark(schema.marks.bold);
  };
  handlers.strong_close = (state) => {
    state.closeMark(schema.marks.bold);
  };

  handlers.s_open = (state) => {
    state.openMark(schema.marks.strike);
  };
  handlers.s_close = (state) => {
    state.closeMark(schema.marks.strike);
  };

  handlers.code_inline = (state, token) => {
    state.openMark(schema.marks.code);
    state.addText(token.content);
    state.closeMark(schema.marks.code);
  };

  handlers.link_open = (state, token) => {
    const href = token.attrGet('href') || '';
    const title = token.attrGet('title') || null;
    state.openMark(schema.marks.link, { href, target: null, title });
  };
  handlers.link_close = (state) => {
    state.closeMark(schema.marks.link);
  };

  // highlight (==text==)
  handlers.mark_open = (state) => {
    state.openMark(schema.marks.highlight);
  };
  handlers.mark_close = (state) => {
    state.closeMark(schema.marks.highlight);
  };

  // superscript (^text^)
  if (schema.marks.superscript) {
    handlers.sup_open = (state) => {
      state.openMark(schema.marks.superscript);
    };
    handlers.sup_close = (state) => {
      state.closeMark(schema.marks.superscript);
    };
  }

  // subscript (~text~)
  if (schema.marks.subscript) {
    handlers.sub_open = (state) => {
      state.openMark(schema.marks.subscript);
    };
    handlers.sub_close = (state) => {
      state.closeMark(schema.marks.subscript);
    };
  }

  // ── 文本和硬换行 ──

  handlers.text = (state, token) => {
    state.addText(token.content);
  };

  handlers.inline = (state, token) => {
    if (token.children) {
      let skipNextSpace = false;
      for (let i = 0; i < token.children.length; i++) {
        const child = token.children[i];
        // 任务列表 checkbox 后，下一个文本节点开头的空格是 checkbox 与内容之间的分隔符
        // 去掉它以保持输出整洁（否则 - [ ] todo → - [ ]  todo）
        if (skipNextSpace && child.type === 'text' && child.content.startsWith(' ')) {
          state.addText(child.content.slice(1));
          skipNextSpace = false;
          continue;
        }
        const handler = handlers[child.type];
        if (handler) {
          handler(state, child, token.children!, i);
          if (child.type === 'html_inline' && child.content.includes('type="checkbox"')) {
            skipNextSpace = true;
          }
        } else if (child.type === 'text') {
          state.addText(child.content);
        }
      }
    }
  };

  handlers.softbreak = (state) => {
    state.addText('\n');
  };

  handlers.hardbreak = (state) => {
    state.addNode(schema.nodes.hardBreak);
  };

  // ── HTML 块（忽略） ──
  handlers.html_block = () => {};
  handlers.html_inline = (state, token) => {
    // 任务列表复选框：inline 在 paragraph 中处理，paragraph 在 taskItem 中
    // 提取 checked="" 状态设置到父级 taskItem 节点
    if (token.content.includes('type="checkbox"')) {
      if (token.content.includes('checked=""')) {
        for (let i = state.stack.length - 1; i >= 0; i--) {
          if (state.stack[i].type.name === 'taskItem') {
            state.stack[i].attrs = { ...state.stack[i].attrs, checked: true };
            break;
          }
        }
      }
      return;
    }
    if (/^<br\s*\/?>$/i.test(token.content.trim())) {
      state.addNode(schema.nodes.hardBreak);
      return;
    }
    state.addText(token.content);
  };

  Object.assign(handlers, getPluginTokenHandlers(schema));

  return handlers;
}

// ── 解析入口 ──────────────────────────��──────────────────────────

const md = createMarkdownIt();

export function parseMarkdown(schema: Schema, content: string): PMNode {
  if (!content || !content.trim()) {
    return schema.nodes.doc.create(null, [schema.nodes.paragraph.create()]);
  }

  const pluginData: Record<string, unknown> = {};
  const state = new MarkdownParseState(schema, pluginData);

  const preprocessors = getPluginPreprocessors(schema);
  const preprocessResults = preprocessors.map((preprocessor) => {
    const result = preprocessor.preprocess({ content });
    content = result.content;
    pluginData[preprocessor.name] = result.data;
    return { preprocessor, data: result.data };
  });

  for (const result of preprocessResults) {
    if (result.preprocessor.beforeParse && result.data !== undefined) {
      result.preprocessor.beforeParse(state, result.data);
    }
  }

  // 1.5. 预处理：插入 ZWNJ，防止 markdown-it 因 Unicode 标点边界拒绝打开或关闭
  // 详见 AGENTS.md 「方案决策」章节了解背景和取舍。
  // 顺序很重要：必须先关后开，避免互踩。
  // 关闭方向：punct**word → punct\u200C**word（如 」**吗 → right_flanking=false）
  // 排除 ASCII 标点（!-/:;?@[-`{-~），它们是 markdown 语法字符而非内容标点。
  content = content.replace(
    /(?<!\*)(?<=[\p{P}\p{S}])(\*+)(?=[^\s\p{P}\p{S}])/gu,
    (_match, delim: string, offset: number) => {
      const prevChar = content[offset - 1];
      if (prevChar && /[\x21-\x2F\x3A-\x40\x5B-\x60\x7B-\x7E]/.test(prevChar)) {
        return delim;
      }
      return '\u200C' + delim;
    },
  );
  // 开启方向：word**punct → word**\u200Cpunct（如 嘿**「→ left_flanking=false）
  content = content.replace(
    /(?<!\*)(?<=[^\s\p{P}\p{S}])(\*{1,2})(?=[\p{P}\p{S}])(?!\*)/gu,
    (_match, delim: string, offset: number) => {
      const nextChar = content[offset + delim.length];
      if (nextChar && /[\x21-\x2F\x3A-\x40\x5B-\x60\x7B-\x7E]/.test(nextChar)) {
        return delim;
      }
      return delim + '\u200C';
    },
  );

  // 2. 用 markdown-it 解析主体内容
  const tokens = md.parse(content, {});
  const handlers = getTokenHandlers(schema);
  const tokenInterceptors = getPluginTokenInterceptors(schema);

  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i];

    if (tokenInterceptors.some((interceptor) => interceptor(state, token, tokens, i))) {
      continue;
    }

    const handler = handlers[token.type];
    if (handler) {
      handler(state, token, tokens, i);
    }
  }

  return state.buildDoc();
}
