<template>
  <div
    v-show="visible"
    ref="menuRef"
    class="bubble-menu"
    :style="{ left: `${pos.left}px`, top: `${pos.top}px`, transform: 'translate(8px, -130%)' }"
    @mousedown.prevent
    @click.stop
  >
    <!-- 主工具栏 -->
    <div class="bubble-menu-toolbar">
      <button :class="btnClass(activeMarks.bold)" title="加粗" @click="exec('bold')">
        <span class="font-bold text-lg">B</span>
      </button>
      <button :class="btnClass(activeMarks.italic)" title="斜体" @click="exec('italic')">
        <span class="italic text-lg">I</span>
      </button>
      <button :class="btnClass(activeMarks.code)" title="行内代码" @click="exec('code')">
        <span class="font-mono text-sm">&lt;/&gt;</span>
      </button>
      <button :class="btnClass(activeMarks.link)" title="链接" @click="toggleLinkInput">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">
          <path d="M6.5 9.5a2.5 2.5 0 0 0 3.54 0l2.12-2.12a2.5 2.5 0 0 0-3.54-3.54l-1.06 1.06" />
          <path d="M9.5 6.5a2.5 2.5 0 0 0-3.54 0L3.84 8.62a2.5 2.5 0 0 0 3.54 3.54l1.06-1.06" />
        </svg>
      </button>
      <div class="bubble-menu-divider"></div>
      <button :class="btnClass(activeMarks.bulletList)" title="无序列表" @click="exec('bulletList')">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round">
          <circle cx="3" cy="4" r="1.2" fill="currentColor" stroke="none" />
          <circle cx="3" cy="8" r="1.2" fill="currentColor" stroke="none" />
          <circle cx="3" cy="12" r="1.2" fill="currentColor" stroke="none" />
          <line x1="6" y1="4" x2="14" y2="4" />
          <line x1="6" y1="8" x2="14" y2="8" />
          <line x1="6" y1="12" x2="14" y2="12" />
        </svg>
      </button>
      <div class="bubble-menu-divider"></div>
      <button class="bubble-menu-heading-btn" @click="exec('h1')">H1</button>
      <button class="bubble-menu-heading-btn" @click="exec('h2')">H2</button>
      <div class="bubble-menu-divider"></div>
      <button class="bubble-menu-clear-btn" title="清除格式" @click="exec('clearFormat')">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">
          <path d="M4 4l8 8" />
          <path d="M3 12h3l1.5-5" />
          <path d="M7 3h6l-1.5 3" />
        </svg>
      </button>
    </div>

    <!-- 链接输入区 -->
    <div v-if="showLinkInput" class="bubble-menu-link-section">
      <input
        ref="linkInputRef"
        v-model="linkUrl"
        type="url"
        placeholder="输入链接地址..."
        class="bubble-menu-input"
        @keydown.enter="applyLink"
        @keydown.escape="cancelLink"
      />
      <button class="bubble-menu-btn-primary" @click="applyLink">
        确定
      </button>
      <button v-if="activeMarks.link" class="bubble-menu-btn-danger" @click="removeLink">
        移除
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, nextTick } from 'vue';

type BubbleMenuActionData = {
  href?: string;
};

type ActiveMarks = {
  bold: boolean;
  italic: boolean;
  code: boolean;
  link: boolean;
  bulletList: boolean;
};

const props = defineProps<{
  onAction: (type: string, data?: BubbleMenuActionData) => void;
}>();

const visible = ref(false);
const pos = reactive({ left: 0, top: 0 });
const activeMarks = reactive({
  bold: false,
  italic: false,
  code: false,
  link: false,
  bulletList: false,
});

// 链接输入相关
const showLinkInput = ref(false);
const linkUrl = ref('');
const linkInputRef = ref<HTMLInputElement | null>(null);

const btnClass = (active: boolean) => [
  'bubble-menu-btn',
  active ? 'bubble-menu-btn--active' : '',
];

const exec = (type: string) => {
  props.onAction(type);
};

// 切换链接输入区
const toggleLinkInput = () => {
  showLinkInput.value = !showLinkInput.value;
  if (showLinkInput.value) {
    nextTick(() => {
      linkInputRef.value?.focus();
    });
  }
};

// 应用链接
const applyLink = () => {
  if (linkUrl.value.trim()) {
    props.onAction('link', { href: linkUrl.value.trim() });
  }
  showLinkInput.value = false;
  linkUrl.value = '';
};

// 移除链接
const removeLink = () => {
  props.onAction('unlink');
  showLinkInput.value = false;
  linkUrl.value = '';
};

// 取消链接输入
const cancelLink = () => {
  showLinkInput.value = false;
  linkUrl.value = '';
};

// 暴露更新方法给插件调用
defineExpose({
  update(show: boolean, left: number, top: number, marks: Partial<ActiveMarks>, linkHref?: string) {
    visible.value = show;
    pos.left = left;
    pos.top = top;
    Object.assign(activeMarks, marks);

    // 如果已有链接，填充 URL
    if (linkHref) {
      linkUrl.value = linkHref;
    }

    // 关闭链接输入区（除非正在编辑链接）
    if (!marks.link) {
      showLinkInput.value = false;
      linkUrl.value = '';
    }
  },
});
</script>

<style scoped>
.bubble-menu {
  position: fixed;
  z-index: 50;
  display: flex;
  flex-direction: column;
  padding: 4px;
  background-color: var(--popover-bg);
  border: 1px solid var(--popover-border);
  border-radius: var(--radius-md);
  box-shadow: var(--popover-shadow);
  transition: all 0.2s;
}

.bubble-menu-toolbar {
  display: flex;
  align-items: center;
  gap: 4px;
}

.bubble-menu-btn {
  display: flex;
  height: 32px;
  width: 32px;
  align-items: center;
  justify-content: center;
  border-radius: var(--radius-sm);
  color: var(--text-color);
  background-color: transparent;
  transition: background-color 0.15s;
  cursor: pointer;
  border: none;
}

.bubble-menu-btn:hover {
  background-color: var(--hover-bg);
}

.bubble-menu-btn--active {
  background-color: var(--primary-light);
  color: var(--primary-color);
}

.bubble-menu-divider {
  margin: 0 4px;
  height: 16px;
  width: 1px;
  background-color: var(--border-color);
}

.bubble-menu-heading-btn {
  padding: 4px 8px;
  font-size: 12px;
  border-radius: var(--radius-sm);
  background-color: transparent;
  color: var(--text-color);
  cursor: pointer;
  border: none;
  transition: background-color 0.15s;
}

.bubble-menu-heading-btn:hover {
  background-color: var(--hover-bg);
}

.bubble-menu-link-section {
  margin-top: 4px;
  padding-top: 4px;
  border-top: 1px solid var(--border-light);
  display: flex;
  align-items: center;
  gap: 4px;
}

.bubble-menu-input {
  width: 180px;
  padding: 4px 8px;
  font-size: 12px;
  background-color: var(--input-bg);
  border: 1px solid var(--input-border);
  border-radius: var(--radius-sm);
  color: var(--text-color);
  outline: none;
}

.bubble-menu-input:focus {
  border-color: var(--input-focus-border);
  box-shadow: var(--input-focus-shadow);
}

.bubble-menu-input::placeholder {
  color: var(--input-placeholder);
}

.bubble-menu-btn-primary {
  padding: 4px 8px;
  font-size: 12px;
  background-color: var(--btn-primary-bg);
  color: var(--btn-primary-text);
  border-radius: var(--radius-sm);
  cursor: pointer;
  border: none;
  transition: background-color 0.15s;
}

.bubble-menu-btn-primary:hover {
  background-color: var(--btn-primary-hover);
}

.bubble-menu-btn-danger {
  padding: 4px 8px;
  font-size: 12px;
  background-color: transparent;
  color: var(--error-color);
  border-radius: var(--radius-sm);
  cursor: pointer;
  border: none;
  transition: background-color 0.15s;
}

.bubble-menu-btn-danger:hover {
  background-color: var(--error-bg);
}

.bubble-menu-clear-btn {
  display: flex;
  height: 32px;
  width: 32px;
  align-items: center;
  justify-content: center;
  border-radius: var(--radius-sm);
  color: var(--muted-color);
  background-color: transparent;
  transition: background-color 0.15s, color 0.15s;
  cursor: pointer;
  border: none;
}

.bubble-menu-clear-btn:hover {
  background-color: var(--hover-bg);
  color: var(--text-color);
}
</style>
