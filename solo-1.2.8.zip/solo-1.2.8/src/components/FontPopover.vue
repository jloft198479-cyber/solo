<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref } from 'vue';
import { useSettingsStore } from '../stores/settings';
import { FONT_OPTIONS } from '../constants/fonts';
import { isFontAvailable, onProgress } from '../services/fontLoader';
import CheckIcon from './icons/CheckIcon.vue';
import './popover-shared.css';

const settingsStore = useSettingsStore();

defineProps<{ isActive: boolean }>();
const emit = defineEmits<{ (e: 'toggle'): void; (e: 'select'): void }>();

const fontOptions = FONT_OPTIONS;
const currentFont = computed(() => settingsStore.settings.fontFamily);

const fontStatus = ref<Record<string, boolean>>({});

async function refreshStatus() {
  for (const opt of fontOptions) {
    fontStatus.value[opt.value] = await isFontAvailable(opt.value);
  }
}

onMounted(refreshStatus);

const progressing = ref<Record<string, number>>({});

const unsub = onProgress((family, pct) => {
  if (pct >= 0) {
    progressing.value = { ...progressing.value, [family]: pct };
  } else {
    progressing.value = { ...progressing.value, [family]: 100 };
    isFontAvailable(family).then((ok) => {
      fontStatus.value[family] = ok;
      if (currentFont.value === family) {
        setTimeout(() => {
          const rest = { ...progressing.value };
          delete rest[family];
          progressing.value = rest;
          emit('select');
        }, 600);
      } else {
        const rest = { ...progressing.value };
        delete rest[family];
        progressing.value = rest;
      }
    });
  }
});

onUnmounted(unsub);

function selectFont(value: string) {
  settingsStore.updateSetting('fontFamily', value);
  // 已可用的字体：立即关闭弹窗；需下载的：弹窗保持打开，看进度条
  if (fontStatus.value[value] !== false) {
    emit('select');
  }
}
</script>

<template>
  <div class="quick-action-item">
    <button class="icon-btn" title="字体" @click.stop="emit('toggle')">
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">
        <path d="M8 2.7v10.6" />
        <path d="M2.7 4.7V3.3a.7.7 0 0 1 .7-.7h9.2a.7.7 0 0 1 .7.7v1.4" />
        <path d="M6 13.3h4" />
      </svg>
    </button>
    <Transition name="quick-popover">
      <div v-if="isActive" class="quick-popover">
        <div class="quick-popover-header">字体</div>
        <div class="quick-popover-list">
          <button
            v-for="opt in fontOptions"
            :key="opt.value"
            class="quick-popover-option"
            :class="{ 'is-active': opt.value === currentFont }"
            @click="selectFont(opt.value)"
          >
            <span class="quick-popover-label">
              {{ opt.label }}
              <template v-if="progressing[opt.value] !== undefined">
                <span class="font-dl-badge font-dl-badge--active">下载 {{ progressing[opt.value] }}%</span>
              </template>
              <template v-else-if="opt.downloadUrl && !fontStatus[opt.value]">
                <span class="font-dl-badge">需下载</span>
              </template>
            </span>
            <CheckIcon v-if="opt.value === currentFont" class="check-icon" />
          </button>
          <!-- 进度条 -->
          <div
            v-for="opt in fontOptions"
            v-show="progressing[opt.value] !== undefined && progressing[opt.value] >= 0"
            :key="'bar-' + opt.value"
            class="font-progress-track"
          >
            <div
              class="font-progress-bar"
              :style="{ width: progressing[opt.value] + '%' }"
            />
          </div>
        </div>
      </div>
    </Transition>
  </div>
</template>

<style scoped>
.font-dl-badge {
  display: inline-block;
  margin-left: 4px;
  padding: 0 5px;
  font-size: 10px;
  line-height: 1.6;
  border-radius: 3px;
  background: color-mix(in srgb, var(--muted-color) 12%, transparent);
  color: var(--muted-color);
  vertical-align: middle;
  font-weight: 500;
}

.font-dl-badge--active {
  background: color-mix(in srgb, var(--primary-color) 12%, transparent);
  color: var(--primary-color);
}

.font-progress-track {
  height: 2px;
  margin: 0 12px 4px;
  border-radius: 1px;
  background: var(--border-color);
  overflow: hidden;
}

.font-progress-bar {
  height: 100%;
  background: var(--primary-color);
  border-radius: 1px;
  transition: width 0.3s ease;
}
</style>
